package com.matan.themtpchaser;

public class QuesSuper {
    String question;

    public QuesSuper(String question) {
        this.question = question;
    }

    public QuesSuper() {

    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }
}
